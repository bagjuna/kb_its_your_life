package org.scoula.controller;

import static org.junit.jupiter.api.Assertions.*;

class HomeControllerTest {

}