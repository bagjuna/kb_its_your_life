package ch06.sec06.exam01;

public class Car {
    //필드 선언
    String model; // null
    boolean start; // 0
    int speed;  // 0

}