package ch06.sec08.exam04;

public class Calculator {

    public double areaRectangle(int weight) {
        return weight * weight;
    }

    public double areaRectangle(int weight, int length) {
        return weight * length;
    }
}
