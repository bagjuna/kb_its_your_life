package ch15.sec05.exam04;

public class Fruit {
    public String name;
    public int price;
}